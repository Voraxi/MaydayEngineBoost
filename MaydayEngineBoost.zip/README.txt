MAYDAY ENGINE BOOST 1.6.0

Windows / Steam Mayday Airways Demo. Tested with Steam build 26546546
and BepInEx 6.0.0-be.793 (Unity IL2CPP, Windows x64).

INSTALL
1. In Steam, right-click Mayday Airways Demo and select Manage > Browse
   local files. This opens the folder containing MaydayAirways.exe.
2. If BepInEx 6 IL2CPP is not already working, download its
   Unity.IL2CPP-win-x64 archive using the guide below. Extract its
   contents beside MaydayAirways.exe. Launch the demo through Steam once
   to generate the BepInEx files, then exit.
3. Copy MaydayEngineBoost.dll from this ZIP into BepInEx\plugins.
   Replace an older copy of the DLL if present.
4. Relaunch through Steam and press F7.

BepInEx guide:
https://docs.bepinex.dev/master/articles/user_guide/installation/unity_il2cpp.html

CONTROLS
- F7 opens the panel. The thrust slider goes from 10% to 600%.
  Reset to stock or Home restores 100%.
- In a loaded flight you host, adjust Main tanks or Reserve and click
  Apply fuel. A main-tank edit sets both sides to the same percentage.
- Press 5 or 6 for the extra hotbar slots in solo play or when you host.

HELP OR UNINSTALL
Check BepInEx\LogOutput.log if F7 does not open the panel. For uninstall,
empty slots 5 and 6, exit the game, and remove MaydayEngineBoost.dll from
BepInEx\plugins. See the GitHub page for troubleshooting and settings.

https://github.com/Voraxi/MaydayEngineBoost
