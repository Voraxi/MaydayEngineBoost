MAYDAY ENGINE BOOST 1.6.0
Mayday Airways Demo for Windows, Steam build 26546546
BepInEx 6 IL2CPP (built against 6.0.0-be.793)

INSTALL
Close the demo. In Steam, right-click Mayday Airways Demo and choose
Manage > Browse local files. Copy MaydayEngineBoost.dll into BepInEx\plugins.
BepInEx is already installed on the PC this mod was built for.
If you have the earlier build, replace its MaydayEngineBoost.dll.

INVENTORY
Your hotbar has six slots in solo play or when you host. Press 5 or 6 to
select the extra slots. The stock scroll wheel cycles through slots 1-4.
To restore the four-slot hotbar, empty slots 5 and 6, quit the game, and
set SlotCount = 4 under [Inventory] in BepInEx\config\local.mayday.engineboost.cfg.

IN-GAME CONTROLS
Press F7 to open or close the Engine thrust panel. The readout shows the
current thrust and how far it is from stock. Drag the slider, click minus or
plus, or use the arrow keys to adjust thrust live from 10% to 600%, in five
percentage point steps. Reset to stock or Home restores 100% immediately.
Settings are saved when you apply a change or finish dragging the slider.

FUEL
While hosting a loaded flight, use the Main tanks and Reserve sliders in the
F7 panel to preview a fuel level, then select Apply fuel. A main-tank edit
sets both wing tanks to the same fill percentage. Unedited tanks keep their
current levels. Fuel changes apply to the current aircraft and burn normally.

CO-OP
Install the DLL on the PC hosting the lobby. Start the demo through Steam and
host as usual. The host applies the multiplier to the two engines' forward
thrust. With the default of 1.25, the aircraft gets 25% more forward thrust.
Above 100%, the mod applies extra forward acceleration when the simulator
would cap engine thrust. Airborne boost tapers from 74 m/s and ends at
80 m/s to avoid triggering the stock overspeed pitch-up. At neutral yoke,
the manual trim assist accounts for the extra speed. Overspeed protections
remain active.

TUNE OR DISABLE
Close the demo. After the first launch with the mod installed, open
BepInEx\config\local.mayday.engineboost.cfg in a text editor. Set
ThrustMultiplier to your preferred value (0.10 to 6.00). Use Enabled = false
to switch off the mod completely. Start the demo again to apply changes.

REMOVE
Empty slots 5 and 6, close the demo, and move MaydayEngineBoost.dll out
of BepInEx\plugins.
That restores stock thrust the next time you launch. You can move the same
DLL back whenever you want. This mod does not replace game files or edit saves.

For a session with all BepInEx mods turned off, close the game, then set
enabled = false under [General] in doorstop_config.ini in the game folder.
Set it back to true and relaunch when you want to load BepInEx again.
